const catchAsync = require("../utils/catchAsync");

module.exports = {
    addBlogController: catchAsync(async (req, res) => {
        res.send({
            success: true,
            message: "Blog Added successfully.",
            blog: {},
        });
    }),

    getBlogsController: catchAsync(async (req, res) => {
        const search = req.query.search || "";
        const pagesize = req.query.pagesize || 10;
        const page = req.query.page || 1;

        res.send({ success: true, blogs: [], total: 0 });
    }),

    getBlogController: catchAsync(async (req, res) => {
        res.send({ success: true, blog: {} });
    }),

    updateBlogController: catchAsync(async (req, res) => {
        res.send({
            success: true,
            message: "Updated successfully!",
            blog: {},
        });
    }),

    deleteBlogController: catchAsync(async (req, res) => {
        res.status(200).json({
            success: true,
            message: `Deleted Successfull.`,
        });
    }),
};
